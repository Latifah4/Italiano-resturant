-- MySQL dump 10.13  Distrib 8.0.28, for macos11 (x86_64)
--
-- Host: localhost    Database: oregaano1
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `contain`
--

DROP TABLE IF EXISTS `contain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contain` (
  `orderId` int NOT NULL,
  `ItemID` int NOT NULL,
  PRIMARY KEY (`orderId`,`ItemID`),
  KEY `ItemID` (`ItemID`),
  CONSTRAINT `contain_ibfk_1` FOREIGN KEY (`orderId`) REFERENCES `orders` (`orderId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `contain_ibfk_2` FOREIGN KEY (`ItemID`) REFERENCES `menu` (`ItemID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contain`
--

LOCK TABLES `contain` WRITE;
/*!40000 ALTER TABLE `contain` DISABLE KEYS */;
INSERT INTO `contain` VALUES (1,1),(8,1),(9,1),(7,2),(8,2),(2,3),(1,4),(2,6),(7,7),(9,8);
/*!40000 ALTER TABLE `contain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee` (
  `ID` int NOT NULL,
  `name` varchar(30) NOT NULL,
  `phoneNumber` varchar(30) NOT NULL,
  `address` varchar(50) NOT NULL,
  `age` int NOT NULL,
  `password` varchar(20) NOT NULL,
  `userName` varchar(15) NOT NULL,
  `MANAGER_ID` int DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `MGR` (`MANAGER_ID`) /*!80000 INVISIBLE */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (1001221,'Lamya','0554456789','Al Nuzha',36,'5678','lamaya2',NULL),(1004433,'Aseel','0552233880','Al Rakah',30,'1234','aseel2',NULL),(1502321,'Fay','0561304668','Al Shati',22,'1234','fay1',1001221),(1503821,'Dana','0552231828','Al Rakah',24,'9101','dana3',1004433),(1503822,'Thuraya','0552231828','Al rawada',24,'9101','thuraya',1001221),(1504542,'Sara','0543322120','Al Wahan',23,'5678','sara2',1001221);
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu` (
  `ItemID` int NOT NULL,
  `nameOfItem` varchar(30) NOT NULL,
  `Description` varchar(50) NOT NULL,
  `calories` float NOT NULL,
  `price` float NOT NULL,
  PRIMARY KEY (`ItemID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` VALUES (1,'Pepsi','Pepsi',150,10),(2,'Water','Sparkling water',0,18),(3,'Sprite','Sprite',145,25),(4,'Passion Fruit Mojito','Mojito with passion fruit syrup',163,35),(5,'Orange Juice','Freshly Squeezed',87,35),(6,'Spaghetti','Spaghetti with pomodoro sauce',897,67),(7,'Burrata Salad','with basil and fres cherry tomato',477,69),(8,'Risotto','Risotto  with creamy cheese and mushroom',989,79),(9,'Alfredo Pasta','Penne pasta with our special alfredo sauce',1200,85),(10,'pizza','grilled chicken pizza',900,73),(11,'mix sea food pasta','mix sea food pasta',1000,97);
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modifiess`
--

DROP TABLE IF EXISTS `modifiess`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `modifiess` (
  `EmpID` int NOT NULL,
  `ItemID` int NOT NULL,
  PRIMARY KEY (`EmpID`,`ItemID`),
  KEY `ItemID` (`ItemID`),
  CONSTRAINT `modifiess_ibfk_1` FOREIGN KEY (`EmpID`) REFERENCES `employee` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `modifiess_ibfk_2` FOREIGN KEY (`ItemID`) REFERENCES `menu` (`ItemID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modifiess`
--

LOCK TABLES `modifiess` WRITE;
/*!40000 ALTER TABLE `modifiess` DISABLE KEYS */;
INSERT INTO `modifiess` VALUES (1503821,2),(1504542,3),(1504542,9);
/*!40000 ALTER TABLE `modifiess` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `orderId` int NOT NULL AUTO_INCREMENT,
  `numOfOrders` int NOT NULL,
  PRIMARY KEY (`orderId`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,2),(2,3),(3,1),(4,2),(5,3),(6,3),(7,2),(8,2),(9,3);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment` (
  `Payment_NO` int NOT NULL AUTO_INCREMENT,
  `PaymentType` varchar(30) NOT NULL,
  `discountPercent` int NOT NULL,
  `TAX` int NOT NULL,
  `EmpID` int DEFAULT NULL,
  PRIMARY KEY (`Payment_NO`),
  KEY `EmpID` (`EmpID`),
  CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`EmpID`) REFERENCES `employee` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
INSERT INTO `payment` VALUES (1,'cash',0,15,1502321),(2,'credit',15,15,1503821),(3,'cash',20,15,1503822);
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-14 23:29:42
